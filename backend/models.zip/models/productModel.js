import mongoose from "mongoose";

// SCHEMA
const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  oldPrice: { type: Number },
  newPrice: { type: Number, required: true },
  image: { type: Array, required: true },
  category: { type: String, required: true },
  subCategory: { type: String, required: true },
  sizes: {
    S: { type: Number, default: 0 },
    M: { type: Number, default: 0 },
    L: { type: Number, default: 0 },
    XL: { type: Number, default: 0 },
    XXL: { type: Number, default: 0 },
    // Add more sizes as needed
  },
  neckType: { type: String, required: true },
  fabricType: { type: String },
  gsm: { type: Number },
  bestSeller: { type: Boolean },
  quantity: { type: Number, required: true }, 
  date: { type: Number, required: true },
});

productSchema.pre('save', function(next) {
  this.quantity = this.sizes.S + this.sizes.M + this.sizes.L + this.sizes.XL + this.sizes.XXL;
  next();
});

const productModel = mongoose.models.product || mongoose.model('Product', productSchema);
export default productModel;
